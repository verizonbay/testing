import static org.junit.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.TestMethodOrder;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import junit.framework.Assert;


public class VeriBayTesting {
	static WebDriver driver;

	@BeforeClass
	public static void BrowserOpen() {
		System.setProperty("webdriver.chrome.driver", "C:\\WebDrivers\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	}
	
	
	public void testLoginFail() throws InterruptedException{
		driver.get("http://192.168.56.1:3000/login");		
		WebElement email = driver.findElement(By.xpath("//*[@id=\"Email ID\"]"));
		email.sendKeys("jenijasmine2218@gmail.com");
		Thread.sleep(1000);
		WebElement password = driver.findElement(By.xpath("//*[@id=\"Password\"]"));
		password.sendKeys("1234");
		Thread.sleep(1000);
		WebElement button = driver.findElement(By.xpath("/html/body/div[1]/main/div/div/div[2]/form/center/button"));
		button.click();
		Thread.sleep(1000);
		
		
	}

	@Test
	@BeforeAll
	public void testLogin() throws InterruptedException {
		driver.get("http://192.168.56.1:3000/login");
		
		WebElement email = driver.findElement(By.xpath("//*[@id=\"Email ID\"]"));
		email.sendKeys("jenijasmine2218@gmail.com");
		Thread.sleep(1000);
		WebElement password = driver.findElement(By.xpath("//*[@id=\"Password\"]"));
		password.sendKeys("123");
		Thread.sleep(1000);
		WebElement button = driver.findElement(By.xpath("/html/body/div[1]/main/div/div/div[2]/form/center/button"));
		button.click();
		Thread.sleep(1000);
		
		

	}

	@Test
	public void testHomePage() throws InterruptedException {
		//driver.get("http://localhost:3000/home");
		WebElement lowToHigh = driver.findElement(
		By.xpath("/html/body/div[1]/main/div/div/div[1]/div/div[2]/div[1]/center/div[2]/button[1]"));
		lowToHigh.click();
		Thread.sleep(5000);
		WebElement highToLow = driver.findElement(
				By.xpath("/html/body/div[1]/main/div/div/div[1]/div/div[2]/div[1]/center/div[2]/button[2]"));
		highToLow.click();
		WebElement electronics = driver.findElement(
				By.xpath("/html/body/div[1]/main/div/div/div[1]/div/div[2]/div[2]/center/div[2]/button[1]"));
		electronics.click();
		Thread.sleep(5000);
		driver.navigate().refresh();
		WebElement automobiles = driver.findElement(
				By.xpath("/html/body/div[1]/main/div/div/div[1]/div/div[2]/div[2]/center/div[2]/button[2]"));
		automobiles.click();
		Thread.sleep(5000);
		driver.navigate().refresh();
		WebElement accessories = driver.findElement(
				By.xpath("/html/body/div[1]/main/div/div/div[1]/div/div[2]/div[2]/center/div[2]/button[3]"));
		accessories.click();
		Thread.sleep(5000);
		driver.navigate().refresh();
		WebElement utilities = driver.findElement(
				By.xpath("/html/body/div[1]/main/div/div/div[1]/div/div[2]/div[2]/center/div[2]/button[4]"));
		utilities.click();
		Thread.sleep(5000);
		driver.navigate().refresh();
		WebElement clothing = driver.findElement(
				By.xpath("/html/body/div[1]/main/div/div/div[1]/div/div[2]/div[2]/center/div[2]/button[4]"));
		clothing.click();
		Thread.sleep(5000);
		driver.navigate().refresh();
		WebElement others = driver.findElement(
				By.xpath("/html/body/div[1]/main/div/div/div[1]/div/div[2]/div[2]/center/div[2]/button[5]"));
		others.click();
		Thread.sleep(3000);
		driver.navigate().refresh();

	}
	
	@Test
	public void testWishlist() throws InterruptedException {
		WebElement wishlist=driver.findElement(By.xpath("/html/body/div[1]/main/div/div/div[3]/div/div[2]/div/div/button"));
		wishlist.click();
		Thread.sleep(2000);
		WebElement wish=driver.findElement(By.xpath("/html/body/div[1]/main/div/div/div[3]/div/div[2]/div/div/div[1]/input"));
		wish.sendKeys("iphone");
		WebElement addWish=driver.findElement(By.xpath("/html/body/div[1]/main/div/div/div[3]/div/div[2]/div/div/div[1]/button[1]"));
		addWish.click();
		
		
	}
	

	@Test
	public void testBuying() throws InterruptedException{
		WebElement addToCart=driver.findElement(
				By.xpath("/html/body/div[1]/main/div/div/div[2]/div/div/table/tbody/tr/td/div/div[1]/div/div/div/div[2]/div/div[2]/button[2]"));
		addToCart.click();
		Thread.sleep(1000);
		WebElement closeAlert=driver.findElement(By.xpath("/html/body/div[3]/div/div/div[3]/a/button"));
		closeAlert.click();
		Thread.sleep(3000);
		WebElement cart=driver.findElement(By.xpath("/html/body/div[1]/main/div/div/div[3]/div/div[1]/div[2]/button"));
		cart.click();
		Thread.sleep(3000);
		WebElement priceDisplayed=driver.findElement(By.xpath("/html/body/div[3]/div/div/div[2]/div/div/table/tbody/tr/td[4]"));
		String priceReturned=priceDisplayed.getText();
		assertEquals("8000000", priceReturned);
		WebElement buyNow=driver.findElement(By.xpath("/html/body/div[3]/div/div/div[3]/div[2]/a/button"));
		buyNow.click();
		WebElement first=driver.findElement(By.xpath("/html/body/div[1]/main/div/div/div/div/div[1]/form/div/div/div[3]/table/tbody/tr[1]/td[1]/input"));
		first.sendKeys("1221");
		WebElement second=driver.findElement(By.xpath("/html/body/div[1]/main/div/div/div/div/div[1]/form/div/div/div[3]/table/tbody/tr[1]/td[2]/input"));
		second.sendKeys("1221");
		WebElement third=driver.findElement(By.xpath("/html/body/div[1]/main/div/div/div/div/div[1]/form/div/div/div[3]/table/tbody/tr[1]/td[3]/input"));
		third.sendKeys("1221");
		WebElement fourth=driver.findElement(By.xpath("/html/body/div[1]/main/div/div/div/div/div[1]/form/div/div/div[3]/table/tbody/tr[1]/td[4]/input"));
		fourth.sendKeys("1221");
		WebElement ex_mm=driver.findElement(By.xpath("/html/body/div[1]/main/div/div/div/div/div[1]/form/div/div/div[3]/table/tbody/tr[2]/td[1]/input"));
		ex_mm.sendKeys("12");
		WebElement ex_yy=driver.findElement(By.xpath("/html/body/div[1]/main/div/div/div/div/div[1]/form/div/div/div[3]/table/tbody/tr[2]/td[2]/input"));
		ex_yy.sendKeys("23");
		WebElement cvv=driver.findElement(By.xpath("/html/body/div[1]/main/div/div/div/div/div[1]/form/div/div/div[3]/table/tbody/tr[2]/td[4]/input"));
		cvv.sendKeys("123");
		Thread.sleep(3000);
		WebElement addCard=driver.findElement(By.xpath("/html/body/div[1]/main/div/div/div/div/div[2]/div/div[2]/button"));
		addCard.click();
		WebElement name=driver.findElement(By.xpath("/html/body/div[1]/main/div/div/div/div/div[1]/form/div/div/div[3]/input"));
		name.sendKeys("Jeni");
		WebElement first1=driver.findElement(By.xpath("/html/body/div[1]/main/div/div/div/div/div[1]/form/div/div/div[4]/table/tbody/tr[1]/td[1]/input"));
		WebElement second1=driver.findElement(By.xpath("/html/body/div[1]/main/div/div/div/div/div[1]/form/div/div/div[4]/table/tbody/tr[1]/td[2]/input"));
		WebElement third1=driver.findElement(By.xpath("/html/body/div[1]/main/div/div/div/div/div[1]/form/div/div/div[4]/table/tbody/tr[1]/td[3]/input"));
		WebElement fourth1=driver.findElement(By.xpath("/html/body/div[1]/main/div/div/div/div/div[1]/form/div/div/div[4]/table/tbody/tr[1]/td[4]/input"));
		WebElement ex_mm1=driver.findElement(By.xpath("/html/body/div[1]/main/div/div/div/div/div[1]/form/div/div/div[4]/table/tbody/tr[2]/td[1]/input"));
		WebElement ex_yy1=driver.findElement(By.xpath("/html/body/div[1]/main/div/div/div/div/div[1]/form/div/div/div[4]/table/tbody/tr[2]/td[2]/input"));
		WebElement cvv1=driver.findElement(By.xpath("/html/body/div[1]/main/div/div/div/div/div[1]/form/div/div/div[4]/table/tbody/tr[2]/td[4]/input"));
		
		first1.sendKeys("1221");
		second1.sendKeys("1221");
		third1.sendKeys("1221");
		fourth1.sendKeys("1221");
		ex_mm1.sendKeys("12");
		ex_yy1.sendKeys("23");
		cvv1.sendKeys("123");
		Thread.sleep(2000);
		WebElement add=driver.findElement(By.xpath("/html/body/div[1]/main/div/div/div/div/div[2]/div/div/button"));
		add.click();
		Thread.sleep(2000);
		WebElement home=driver.findElement(By.xpath("/html/body/div[1]/nav/div/ul/a[2]/button"));
		home.click();
		Thread.sleep(2000);
	}
	

	public void logout() throws InterruptedException{
		
		WebElement logout=driver.findElement(By.xpath("/html/body/div[1]/nav/div/ul/a[4]/button"));
		logout.click();
		Thread.sleep(5000);
	}
	
	
	
	
	public void addProduct() throws InterruptedException {
		driver.get("http://localhost:3000/home");
		WebElement addProduct = driver.findElement(By.xpath("/html/body/div[1]/main/div/div/div/div/div/div/button"));
		addProduct.click();
		Thread.sleep(5000);
		WebElement username = driver.findElement(By.xpath("/html/body/div[3]/div/div/div[2]/div/form/div[1]/input"));
		WebElement productType = driver.findElement(By.xpath("/html/body/div[3]/div/div/div[2]/div/form/div[2]/input"));
		WebElement name = driver.findElement(By.xpath("/html/body/div[3]/div/div/div[2]/div/form/div[3]/input"));
		WebElement catagory = driver.findElement(By.xpath("/html/body/div[3]/div/div/div[2]/div/form/div[4]/input"));
		WebElement shortDesc = driver.findElement(By.xpath("/html/body/div[3]/div/div/div[2]/div/form/div[5]/input"));
		WebElement longDesc = driver.findElement(By.xpath("/html/body/div[3]/div/div/div[2]/div/form/div[6]/input"));
		WebElement bidAmount = driver.findElement(By.xpath("/html/body/div[3]/div/div/div[2]/div/form/div[7]/input"));
		WebElement price = driver.findElement(By.xpath("/html/body/div[3]/div/div/div[2]/div/form/div[8]/input"));

		username.sendKeys("tanuj");
		productType.sendKeys("car");
		name.sendKeys("volkswagen polo");
		catagory.sendKeys("automobile");
		shortDesc.sendKeys("Working car. excellent condition");
		longDesc.sendKeys("5 year old car. nice car. works well. serviced.");
		bidAmount.sendKeys("500000");
		price.sendKeys("700000");

	}

	public void testRegister() throws InterruptedException {
		driver.get("http://192.168.56.1:3000/register");
		WebElement username = driver.findElement(By.xpath("//*[@id=\"Username\"]"));
		WebElement email = driver.findElement(By.xpath("//*[@id=\"Email ID\"]"));
		WebElement password = driver.findElement(By.xpath("//*[@id=\"Password\"]"));
		WebElement address = driver.findElement(By.xpath("//*[@id=\"Address\"]"));
		WebElement city = driver.findElement(By.xpath("//*[@id=\"City\"]"));
		WebElement contact = driver.findElement(By.xpath("//*[@id=\"Contact Number\"]"));
		WebElement regButton = driver.findElement(By.xpath("/html/body/div[1]/main/div/div/div[2]/form/center/button"));

		username.sendKeys("Tanuj");
		email.sendKeys("tanuj@gmail.com");
		password.sendKeys("123");
		address.sendKeys("punjab");
		city.sendKeys("punjab");
		contact.sendKeys("9876543212");
		Thread.sleep(5000);
		regButton.click();

	}
	

	
	@AfterClass 
	public static void BrowserClose() { 
		driver.quit(); 
		}
	 
}
